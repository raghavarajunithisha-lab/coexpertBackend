import os
import json
import boto3
import psycopg2
from langfuse import get_client

# Initialize Langfuse client
client = get_client()

# Load database secret from Secrets Manager
SECRET_NAME = os.environ["RDS_SECRET_NAME"]
REGION_NAME = os.environ.get("AWS_REGION", "us-east-1")

secrets_client = boto3.client("secretsmanager", region_name=REGION_NAME)
secret_value = secrets_client.get_secret_value(SecretId=SECRET_NAME)
secret_dict = json.loads(secret_value["SecretString"])

# Extract DB credentials from the secret
DB_HOST = os.environ['DB_HOST']
DB_NAME = os.environ.get('DB_NAME', 'postgres')
DB_USER = secret_dict["username"]
DB_PASS = secret_dict["password"]


def save_feedback(question, rating):
    """
    Insert the feedback record into the Aurora PostgreSQL database.
    """

    # Record the database insert operation as a span
    with client.start_as_current_observation(
        as_type="span",
        name="aurora_insert_feedback",
        metadata={"question": question, "rating": rating}
    ):
        # Connect to Aurora
        conn = psycopg2.connect(
            host=DB_HOST,
            dbname=DB_NAME,
            user=DB_USER,
            password=DB_PASS,
            sslmode='require'
        )
        cur = conn.cursor()

        # Insert the feedback row
        cur.execute(
            "INSERT INTO feedback (question, rating) VALUES (%s, %s)",
            (question, rating)
        )
        conn.commit()

        cur.close()
        conn.close()


def lambda_handler(event, context):
    """
    Handle the API request, create a trace, and save the feedback entry.
    """

    # Parse request body
    body = json.loads(event.get("body", "{}"))
    question = body.get("question", "")
    rating = body.get("rating", "")
    user_id = body.get("userId", "anonymous")

    # Create a unique trace ID for this request
    external_id = f"{user_id}-{context.aws_request_id}"
    trace_id = client.create_trace_id(seed=external_id)

    # Start the main trace for this request
    with client.start_as_current_observation(
        as_type="trace",
        name="submit_feedback",
        trace_context={"trace_id": trace_id},
        metadata={
            "user_id": user_id,
            "question": question,
            "rating": rating
        }
    ) as trace_obs:

        # Span to represent the feedback saving step
        with client.start_as_current_observation(
            as_type="span",
            name="save_feedback_to_db",
            trace_context={"trace_id": trace_id},
        ):
            save_feedback(question, rating)

    # Ensure all Langfuse data is uploaded
    client.flush()

    # Return API response
    return {
        "statusCode": 200,
        "body": json.dumps({
            "ok": True,
            "traceId": trace_id
        })
    }
