import os
import json
import time
import boto3
import psycopg2
from langfuse import get_client

# Initialize Langfuse client
client = get_client()

# Initialize Bedrock runtime client
bedrock = boto3.client("bedrock-runtime")

# Load database secret from AWS Secrets Manager
SECRET_NAME = os.environ["RDS_SECRET_NAME"]
REGION_NAME = os.environ.get("AWS_REGION", "us-east-1")

secrets_client = boto3.client("secretsmanager", region_name=REGION_NAME)
secret_value = secrets_client.get_secret_value(SecretId=SECRET_NAME)
secret_dict = json.loads(secret_value["SecretString"])

# Database credentials
DB_HOST = os.environ["DB_HOST"]
DB_NAME = os.environ["DB_NAME"]
DB_USER = secret_dict["username"]
DB_PASS = secret_dict["password"]

# Bedrock model to use for generation
BEDROCK_MODEL_ID = os.environ["BEDROCK_MODEL_ID"]


def query_kb(question, limit=3):
    """
    Query the Aurora PostgreSQL knowledge base for the most relevant topics.
    """
    with client.start_as_current_observation(
        as_type="span",
        name="aurora_query",
        metadata={"question": question}
    ):
        # Connect to Aurora PostgreSQL
        conn = psycopg2.connect(
            host=DB_HOST,
            dbname=DB_NAME,
            user=DB_USER,
            password=DB_PASS,
            sslmode="require",
        )
        cur = conn.cursor()

        # Simple text search against the KB
        cur.execute("""
            SELECT topic, content
            FROM inspection_tips
            WHERE content_tsv @@ plainto_tsquery('english', %s)
            LIMIT %s
        """, (question, limit))

        rows = cur.fetchall()

        cur.close()
        conn.close()

        return rows


def call_bedrock(question, kb_text):
    """
    Call the Bedrock model with the user question and KB context.
    """
    system_prompt = (
        "You are an inspection assistant. Use the provided context. "
        "If the context does not contain an answer, say 'I don't know'."
    )

    # Build the model input request body
    body = json.dumps({
        "anthropic_version": "bedrock-2023-05-31",
        "system": system_prompt,
        "messages": [
            {"role": "user", "content": f"Context:\n{kb_text}\n\nQuestion: {question}"}
        ],
        "max_tokens": 500,
        "temperature": 0.2
    })

    # Track the Bedrock call as a span
    with client.start_as_current_observation(
        as_type="span",
        name="bedrock_llm_call",
        metadata={"model": BEDROCK_MODEL_ID}
    ):
        response = bedrock.invoke_model(
            body=body,
            contentType="application/json",
            accept="application/json",
            modelId=BEDROCK_MODEL_ID,
        )

        # Extract and return the model output text
        data = json.loads(response["body"].read().decode("utf-8"))
        answer = data["content"][0]["text"].strip()
        return answer


def lambda_handler(event, context):
    """
    Main Lambda entry point.
    Handles the incoming request, queries the knowledge base,
    calls the Bedrock model, and logs the full trace with Langfuse.
    """

    # Parse input request
    body = json.loads(event.get("body", "{}"))
    question = body.get("question", "")
    user_id  = body.get("userId", "anonymous")

    # Generate a unique trace ID based on user and timestamp
    external_id = f"{user_id}-{int(time.time()*1000)}"
    trace_id = client.create_trace_id(seed=external_id)

    # Start the top-level trace
    with client.start_as_current_observation(
        as_type="trace",
        name="inspection_query",
        trace_context={"trace_id": trace_id},
        metadata={"user_id": user_id}
    ) as trace_obs:

        # Query the KB for related inspection tips
        rows = query_kb(question)

        if rows:
            topics = [r[0] for r in rows]
            primary_topic = topics[0]
        else:
            topics = []
            primary_topic = "Unknown"

        # Record topic metadata into the trace
        trace_obs.update(
            metadata={
                "category": primary_topic,
                "topics_used": topics
            }
        )

        # Combine KB text into a single string for LLM input
        kb_text = "\n\n".join(f"{r[0]}: {r[1]}" for r in rows) if rows else ""

        # Call Bedrock and catch any errors
        try:
            answer = call_bedrock(question, kb_text)
            is_failure = False
            needs_support = False

        except Exception as e:
            # Mark failure and save the error message
            answer = "Internal error"
            is_failure = True
            needs_support = True

            trace_obs.update(
                metadata={
                    "is_failure": True,
                    "needs_support": True,
                    "error": str(e)
                }
            )
            raise

        # Create a span representing the generation step (for trace clarity)
        with client.start_as_current_observation(
            as_type="span",
            name="bedrock_generation",
            trace_context={"trace_id": trace_id},
            metadata={
                "model": BEDROCK_MODEL_ID,
                "question": question,
                "kb_text": kb_text,
                "answer": answer,
                "category": primary_topic
            }
        ):
            pass

        # Always store success/failure flags on the trace
        trace_obs.update(
            metadata={
                "is_failure": is_failure,
                "needs_support": needs_support
            }
        )

    # Ensure all observations are sent before Lambda exits
    client.flush()

    # Return the final response payload
    return {
        "statusCode": 200,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps({
            "answer": answer,
            "traceId": trace_id,
            "category": primary_topic
        })
    }
