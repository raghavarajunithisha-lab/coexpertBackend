import os
import json
import time
import boto3
import psycopg2
from langfuse import get_client, propagate_attributes

# Initialize Langfuse client (used to record traces, spans, tags, metadata)
client = get_client()

# Bedrock runtime client (used to call the LLM model)
bedrock = boto3.client("bedrock-runtime", region_name="us-east-1")


# === Load DB Secret from AWS Secrets Manager ===
SECRET_NAME = os.environ["RDS_SECRET_NAME"]
REGION_NAME = os.environ.get("AWS_REGION", "us-east-1")
print(f"REGION_NAME: {REGION_NAME}")

# Connect to Secrets Manager and fetch the DB credentials JSON
secrets_client = boto3.client("secretsmanager", region_name=REGION_NAME)
secret_value = secrets_client.get_secret_value(SecretId=SECRET_NAME)
secret_dict = json.loads(secret_value["SecretString"])

# Extract username and password
DB_HOST = os.environ["DB_HOST"]
DB_NAME = os.environ["DB_NAME"]
DB_USER = secret_dict["username"]
DB_PASS = secret_dict["password"]

# Bedrock model ID to call (set in Lambda environment variables)
BEDROCK_MODEL_ID = os.environ["BEDROCK_MODEL_ID"]


def query_kb(question, limit=3):
    """
    Look up relevant inspection topics from Aurora PostgreSQL.
    Uses full-text search to find matches for the user's question.
    Langfuse span is created for observability.
    """

    # Start a Langfuse span for the DB query
    with client.start_as_current_observation(
        as_type="span",
        name="aurora_query",
        metadata={"question": question}
    ):
        # Connect to PostgreSQL
        conn = psycopg2.connect(
            host=DB_HOST,
            dbname=DB_NAME,
            user=DB_USER,
            password=DB_PASS,
            sslmode="require",
        )
        cur = conn.cursor()

        # Simple full-text search query
        cur.execute("""
            SELECT topic, content
            FROM inspection_tips
            WHERE content_tsv @@ plainto_tsquery('english', %s)
            LIMIT %s
        """, (question, limit))

        rows = cur.fetchall()

        cur.close()
        conn.close()

        return rows


def call_bedrock(question, kb_text):
    """
    Call the Bedrock LLM with the question and the optional KB context.
    Wrap the call inside a Langfuse span for observability.
    """

    # System instruction for the model
    system_prompt = (
        "You are an inspection assistant. Use the provided context. "
        "If the context does not contain an answer, say 'I don't know'."
    )

    # Build model request
    body = json.dumps({
        "anthropic_version": "bedrock-2023-05-31",
        "system": system_prompt,
        "messages": [
            {"role": "user", "content": f"Context:\n{kb_text}\n\nQuestion: {question}"}
        ],
        "max_tokens": 500,
        "temperature": 0.2
    })

    # Langfuse span for the model call
    with client.start_as_current_observation(
        as_type="span",
        name="bedrock_llm_call",
        metadata={"model": BEDROCK_MODEL_ID}
    ):
        # Call the Bedrock model
        response = bedrock.invoke_model(
            body=body,
            contentType="application/json",
            accept="application/json",
            modelId=BEDROCK_MODEL_ID,
        )

        # Extract and clean up the model answer
        data = json.loads(response["body"].read().decode("utf-8"))
        answer = data["content"][0]["text"].strip()
        return answer


def lambda_handler(event, context):
    """
    Main Lambda entry point.
    Steps:
    - Read user question
    - Start Langfuse trace
    - Query KB
    - Apply tags (primary topic)
    - Call Bedrock
    - Record spans + metadata
    - Return answer to frontend
    """

    # Parse incoming request
    body = json.loads(event.get("body", "{}"))
    question = body.get("question", "")
    user_id = body.get("userId", "anonymous")

    # Create unique trace ID
    external_id = f"{user_id}-{int(time.time()*1000)}"
    trace_id = client.create_trace_id(seed=external_id)

    # Start entire trace
    with client.start_as_current_observation(
        as_type="trace",
        name="inspection_query",
        trace_context={"trace_id": trace_id},
        metadata={"user_id": user_id}
    ) as trace_obs:

        # Query the knowledge base
        rows = query_kb(question)

        # Extract topics from DB
        if rows:
            topics = [r[0] for r in rows]
            primary_topic = topics[0]  # first result = main topic
        else:
            topics = []
            primary_topic = "Unknown"

        # Store topics in trace metadata
        trace_obs.update(
            metadata={
                "category": primary_topic,
                "topics_used": topics
            }
        )

        # === Apply TAGS to the whole trace ===
        # The tag is the "primary topic"
        with propagate_attributes(tags=[primary_topic]):

            # Convert DB rows into formatted text
            kb_text = "\n\n".join(f"{r[0]}: {r[1]}" for r in rows) if rows else ""

            try:
                # Call LLM
                answer = call_bedrock(question, kb_text)
                is_failure = False
                needs_support = False

            except Exception as e:
                # Handle model or DB errors
                answer = "Internal error"
                is_failure = True
                needs_support = True

                # Add error details to trace
                trace_obs.update(
                    metadata={
                        "is_failure": True,
                        "needs_support": True,
                        "error": str(e)
                    }
                )
                raise

            # Span for logging LLM generation metadata
            with client.start_as_current_observation(
                as_type="span",
                name="bedrock_generation",
                trace_context={"trace_id": trace_id},
                metadata={
                    "model": BEDROCK_MODEL_ID,
                    "question": question,
                    "kb_text": kb_text,
                    "answer": answer,
                    "category": primary_topic
                }
            ):
                pass

        # Final update on failure/support flags
        trace_obs.update(
            metadata={
                "is_failure": is_failure,
                "needs_support": needs_support
            }
        )

    # Ensure all Langfuse events are sent
    client.flush()

    # Return response to frontend
    return {
        "statusCode": 200,
        "headers": {
            "Access-Control-Allow-Origin": "http://localhost:3000",
            "Access-Control-Allow-Headers": "Content-Type, Authorization",
            "Access-Control-Allow-Methods": "OPTIONS,POST,GET",
        },
        "body": json.dumps({
            "answer": answer,
            "traceId": trace_id,
            "category": primary_topic
        })
    }
